package springfield.academy.schoolinformationsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchoolinformationsystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(SchoolinformationsystemApplication.class, args);
	}

}
