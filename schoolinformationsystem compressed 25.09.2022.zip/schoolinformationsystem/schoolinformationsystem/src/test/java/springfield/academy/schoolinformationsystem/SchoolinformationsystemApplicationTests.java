package springfield.academy.schoolinformationsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchoolinformationsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
